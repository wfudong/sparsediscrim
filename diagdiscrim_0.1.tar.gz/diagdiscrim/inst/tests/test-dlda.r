library('diagdiscrim')
library('mvtnorm')

context("Diagonalized Discriminant Analysis")

test_that("DLDA with 3 classes having identity covariance matrix", {
	set.seed(42)
	n1 <- n2 <- n3 <- 10
	p <- 3
	mu1 <- 0
	mu2 <- 2
	mu3 <- 4

	x1 <- rmvnorm(n1, rep(mu1, p))
	x2 <- rmvnorm(n2, rep(mu2, p))
	x3 <- rmvnorm(n3, rep(mu3, p))
	
	train.df <- rbind.data.frame(cbind(1, x1), cbind(2, x2), cbind(3, x3))
	dlda.out <- dlda(train.df)
	cov1 <- (n1 - 1) * cov(x1) / n1
	
	
	
	
	expect_that(TRUE, equals(TRUE))
})


