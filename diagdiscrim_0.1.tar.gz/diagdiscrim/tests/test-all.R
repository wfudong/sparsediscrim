#library('testthat')
#library('diagdiscrim')

#test_package('diagdiscrim')