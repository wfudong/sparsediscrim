Diagonal Discriminant Analysis

