library('e1071')

context("Diagonalized Discriminant Analysis")

test_that("DLDA's matches predefined predictions", {
	# TODO: expect_that(dlda, equals(output_from_e1071_implementation_of_naive_bayes))
	expect_that(TRUE, equals(TRUE))
})

test_that("DQDA's matches predefined predictions", {
	# TODO: expect_that(dlda, equals(output_from_e1071_implementation_of_naive_bayes))
	expect_that(TRUE, equals(TRUE))
})

test_that("SDLDA's matches predefined predictions", {
	# TODO: expect_that(dlda, equals(output_from_e1071_implementation_of_naive_bayes))
	expect_that(TRUE, equals(TRUE))
})

test_that("SDQDA's matches predefined predictions", {
	# TODO: expect_that(dlda, equals(output_from_e1071_implementation_of_naive_bayes))
	expect_that(TRUE, equals(TRUE))
})

test_that("RSDDA's matches predefined predictions", {
	# TODO: expect_that(dlda, equals(output_from_e1071_implementation_of_naive_bayes))
	expect_that(TRUE, equals(TRUE))
})